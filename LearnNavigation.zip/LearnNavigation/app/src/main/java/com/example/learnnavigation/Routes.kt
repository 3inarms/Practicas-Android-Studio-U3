package com.example.learnnavigation

object Routes {
    var screenA = "screen_A"
    var screenB = "screen_B"

    var screenC = "screen_C"

}